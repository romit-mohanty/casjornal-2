import { Link } from 'react-router-dom';

const Service = () => {
    const style = {
        backgroundColor: '#3fcc5e'
    }

    return (
        <div className="card" style={style}>
            <Link to='/service' className="text-light" style={{ textDecoration: 'none' }}>
                <div className="card-body">
                    <h5 className="card-title">Service</h5>
                    <h6 className="card-subtitle">Click to see service list</h6>
                </div>
            </Link>
        </div>
    );
}

export default Service;