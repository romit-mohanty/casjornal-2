import { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import StudentList from './StudentList';

const Home = () => {
    const [logoutValue, setLogoutValue] = useState(sessionStorage.length);
    const history = useHistory();

    useEffect(() => {
        if(logoutValue < 2) {
            history.push('/login');
        }
    }, [logoutValue])

    return (
        <div className="container text-center">
            <StudentList />
        </div>
    );
}

export default Home;