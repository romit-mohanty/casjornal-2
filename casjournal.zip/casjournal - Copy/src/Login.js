import { useState, useEffect } from 'react';
import { Link, useHistory } from 'react-router-dom';

const Login = () => {
    const [userName, setUserName] = useState('');
    const [password, setPassword] = useState('');
    const [loginError, setLoginError] = useState(false);
    const [loginErrorMessage, setLoginErrorMessage] = useState('');
    const [serverError, setServerError] = useState(false);
    const [serverErrorMessage, setServerErrorMessage] = useState('');
    // const [signedUp, setSignedUp] = useState(false);
    // const [signedUpMessage, setSignedUpMessage] = useState('');

    const history = useHistory();

    useEffect(() => {
        let storageLength = sessionStorage.length;
        if(storageLength > 0) {
            history.push('/');
        }
    }, [])

    const handleSubmit = (event) => {
        event.preventDefault();

        fetch('http://localhost:8000/teachers?username=' + userName + '&password=' + password)
            .then(res => {
                return res.json();
            })
            .then(data => {
                if(data.length !== 0) {
                    sessionStorage.setItem('userName', userName);
                    sessionStorage.setItem('password', password);
                    history.push('/');
                } else {
                    setLoginError(true);
                    setLoginErrorMessage('Your username or password is incorrect.');
                }
            })
            .catch(err => {
                setServerError(true);
                setServerErrorMessage('Something went wrong.');
            });
    }

    return (
        <div className="container text-center">
            <h2>Login to begin your journalling your CAS journey</h2>
            <div className="row">
                <div className="col" style={{ border: '1px solid #8f8f8f'}}>
                    { serverError && <div className='alert alert-danger'>{ serverErrorMessage }</div> }
                    { loginError && <div className='alert alert-danger'>{ loginErrorMessage }</div> }
                    <form onSubmit={handleSubmit}>
                        <div className="mb-3">
                            <label className='form-label'>Username</label>
                            <input
                                type="text"
                                className='form-control'
                                value={userName}
                                onChange={event => setUserName(event.target.value)}
                                required
                            />
                        </div>
                        <div className="mb-3">
                            <label className='form-label'>Password</label>
                            <input
                                type="password"
                                className='form-control'
                                value={password}
                                onChange={event => setPassword(event.target.value)}
                                required
                            />
                        </div>
                        <div className="mb-3">
                            <button className="btn btn-primary">Login</button>
                        </div>
                    </form>
                </div>
                <div className="col" style={{ border: '1px solid #8f8f8f' }}>
                    <div className="row d-flex justify-content-center align-items-center">Or Sign up!</div>
                    <div className="row d-flex justify-content-center align-items-center">
                        <Link to='/signup'><button className="btn btn-primary">SignUp!</button></Link>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Login;