import { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';

const Signup = () => {
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [username, setUserName] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    const [passDoesNotMatchError, setPassDoesNotMatchError] = useState(false);
    const [passDoesNotMatchErrorMessage, setPassDoesNotMatchErrorMessage] = useState('');
    const [usernameAlreadyTakenError, setUsernameAlreadyTakenError] = useState(false);
    const [usernameAlreadyTakenErrorMessage, setUsernameAlreadyTakenErrorMessage] = useState('');
    const [serverError, setServerError] = useState(false);
    const [serverErrorMessage, setServerErrorMessage] = useState('');

    const history = useHistory();

    useEffect(() => {
        let storageLength = sessionStorage.length;
        if(storageLength > 0) {
            history.push('/');
        }
    }, [])

    const handleOnSubmit = (event) => {
        event.preventDefault();
        if(password !== confirmPassword) {
            setPassDoesNotMatchError(true);
            setPassDoesNotMatchErrorMessage('Passwords do not match.');
        } else {
            setPassDoesNotMatchError(false);
            setPassDoesNotMatchErrorMessage('');
            fetch('http://localhost:8000/teachers?username=' + username)
                .then(res => {
                    return res.json();
                })
                .then(data => {
                    if(data.length !== 0) {
                        setUsernameAlreadyTakenError(true);
                        setUsernameAlreadyTakenErrorMessage('Username already taken.');
                    } else {
                        setUsernameAlreadyTakenError(false);
                        setUsernameAlreadyTakenErrorMessage('');

                        const teacher = { firstName, lastName, username, password };
                        fetch('http://localhost:8000/teachers', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify(teacher)
                        })
                        .then(() => {
                            history.push('/login');
                        })
                    }
                })
                .catch(err => {
                    setServerError(true);
                    setServerErrorMessage('Something went wrong.');
                });
        }
    }

    return (
    <div>
        <h2>Signup!</h2>
        <div className="container text-center">
            { passDoesNotMatchError && <div className='alert alert-danger'>{ passDoesNotMatchErrorMessage }</div> }
            { usernameAlreadyTakenError && <div className='alert alert-danger'>{ usernameAlreadyTakenErrorMessage }</div> }
            { serverError && <div className='alert alert-danger'>{ serverErrorMessage }</div> }
            <form>
                <div className="mb-3">
                    <label className='form-label'>First Name</label>
                    <input type="text" value={firstName} className='form-control' onChange={event => setFirstName(event.target.value)} required></input>
                </div>
                <div className="mb-3">
                    <label className='form-label'>Last Name</label>
                    <input type="text" value={lastName} className='form-control' onChange={event => setLastName(event.target.value)} required></input>
                </div>
                <div className="mb-3">
                    <label className='form-label'>Username</label>
                    <input type="text" value={username} className='form-control' onChange={event => setUserName(event.target.value)} required></input>
                </div>
                <div className="mb-3">
                    <label className='form-label'>Password</label>
                    <input type="password" value={password} className='form-control' onChange={event => setPassword(event.target.value)} required></input>
                </div>
                <div className="mb-3">
                    <label className='form-label'>Confirm Password</label>
                    <input type="password" value={confirmPassword} className='form-control' onChange={event => setConfirmPassword(event.target.value)} required></input>
                </div>
                <div className='mb-3'>
                    <button className='btn btn-primary' onClick={handleOnSubmit}>Sign Up!</button>
                </div>
            </form>
        </div>
    </div>
    );
}

export default Signup;