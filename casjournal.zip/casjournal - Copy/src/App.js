import { BrowserRouter, Switch, Route } from "react-router-dom";

import Home from './Home.js';
import CreativityList from './CreativityList.js';
import ActivityList from './ActivityList.js';
import ServiceList from './ServiceList.js';
import Navbar from './Navbar.js';
import StudentPortfolio from "./StudentPortfolio.js";
import Login from "./Login.js";
import Signup from "./Signup.js";

function App() {
  return (
    <BrowserRouter>
      <div>
        <Navbar />
        <Switch>
          <Route exact path='/'>
            <Home />
          </Route>
          <Route path='/creativity'>
            <CreativityList />
          </Route>
          <Route path='/activity'>
            <ActivityList />
          </Route>
          <Route path='/service'>
            <ServiceList />
          </Route>
          <Route path='/portfolio/:id'>
            <StudentPortfolio />
          </Route>
          <Route path='/login'>
            <Login />
          </Route>
          <Route path='/signup'>
            <Signup />
          </Route>
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;
