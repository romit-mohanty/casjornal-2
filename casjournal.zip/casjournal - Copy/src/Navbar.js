import { useState, useEffect } from 'react';
import { Link, useHistory } from 'react-router-dom';

const Navbar = () => {
    const [logoutValue, setLogoutValue] = useState(sessionStorage.length);
    const [showNavButton, setShowNavButton] = useState(true);
    const history = useHistory();

    useEffect(() => {
        if(logoutValue < 2) {
            history.push('/login');
        }
    }, [logoutValue])
    
    const handleLogout = (event) => {
        sessionStorage.clear();
        setShowNavButton(false);
        history.push('/login');
    }

    return (
        <div>
            <nav className="navbar navbar-expand-lg bg-primary">
                <div className="container-fluid">
                    <div className="navbar-brand">
                        CAS Journal
                    </div>
                    <div className="collapse navbar-collapse">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item">
                                <Link to='/' className="text-light" style={{ textDecoration: 'none' }}>Home</Link>
                            </li>
                        </ul>
                    </div>
                    <button className="btn btn-light" style={{ float: 'right' }} onClick={handleLogout}>Logout</button>
                </div>
            </nav>
        </div>
    );
}

export default Navbar;