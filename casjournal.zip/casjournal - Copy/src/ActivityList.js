import { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';

const ActivityList = () => {
    const [logoutValue, setLogoutValue] = useState(sessionStorage.length);
    const history = useHistory();

    useEffect(() => {
        if(logoutValue < 2) {
            history.push('/login');
        }
    }, [logoutValue])

    const style = {
        marginTop: '5px',
        marginRight: '5px',
        marginBottom: '5px',
        marginLeft: '5px',
        backgroundColor: '#3f8acc'
    }

    const handleGoBack = (event) => {
        history.go(-1);
    }

    return (
        <div style={{ marginTop: '5px' }}>
            <div className="card" style={style}>
                <div className="card-body">
                    <button className='btn btn-light' onClick={handleGoBack}>Go Back</button>
                    <h5 className="card-title text-light">Welcome to Activity!</h5>
                </div>
            </div>
            <div className="container text-center">
                <div className="row">
                    <div className="col" style={{ border: '1px solid #8f8f8f' }}>
                        Student Experience
                    </div>
                    <div className="col" style={{ border: '1px solid #8f8f8f' }}>
                        Student Project
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ActivityList;