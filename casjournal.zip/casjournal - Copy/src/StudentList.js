import useFetch from './useFetch.js';
import { Link } from 'react-router-dom';

const StudentList = () => {
    const { data, isPending, error } = useFetch('http://localhost:8000/students');

    return (
        <div style={{ marginTop: '5px' }}>
            { isPending && <div>Loading...</div> }
            { data && <div className="container text-center">
                <div className="row">
                    <div className="col bg-primary text-light" style={{ border: '1px solid #8f8f8f' }}>Your CAS Mentees</div>
                </div>
                <div className="row">
                    <div className="col bg-primary text-light" style={{ border: '1px solid #8f8f8f' }}>
                        First Name
                    </div>
                    <div className="col bg-primary text-light" style={{ border: '1px solid #8f8f8f' }}>
                        Last Name
                    </div>
                    <div className="col bg-primary text-light" style={{ border: '1px solid #8f8f8f' }}>
                        Grade/Section
                    </div>
                    <div className="col bg-primary text-light" style={{ border: '1px solid #8f8f8f' }}>
                        Attendance at meeting
                    </div>
                    <div className="col bg-primary text-light" style={{ border: '1px solid #8f8f8f' }}>
                        Student ID
                    </div>
                    <div className="col bg-primary text-light" style={{ border: '1px solid #8f8f8f' }}>
                        Student Portfolio
                    </div>
                </div>
                { data.map(student => (
                    <div className="row" key={ student.id }>
                        <div className="col" style={{ border: '1px solid #8f8f8f' }}>
                            { student.firstName }
                        </div>
                        <div className="col" style={{ border: '1px solid #8f8f8f' }}>
                            { student.lastName }
                        </div>
                        <div className="col" style={{ border: '1px solid #8f8f8f' }}>
                            { student.gradeSection }
                        </div>
                        <div className="col" style={{ border: '1px solid #8f8f8f' }}>
                            { student.attendanceAtMeeting }
                        </div>
                        <div className="col" style={{ border: '1px solid #8f8f8f' }}>
                            { student.studentId }
                        </div>
                        <div className="col" style={{ border: '1px solid #8f8f8f' }}>
                            <Link to={`/portfolio/${student.id}`} className="text-dark" style={{ textDecoration: 'none' }}>
                                Portfolio
                            </Link>
                        </div>
                    </div>)
                )}
            </div> }
            { error && <div>{error}</div> }
        </div>
    );
}

export default StudentList;