import { useState, useEffect } from 'react';
import { useParams, useHistory } from 'react-router-dom';
import useFetch from './useFetch.js';

import Creativity from './Creativity.js';
import Activity from './Activity.js';
import Service from './Service.js';

const StudentPortfolio = () => {
    const { id } = useParams();
    const { data, isPending, error } = useFetch('http://localhost:8000/students/' + id);

    const [logoutValue, setLogoutValue] = useState(sessionStorage.length);
    const history = useHistory();

    useEffect(() => {
        if(logoutValue < 2) {
            history.push('/login');
        }
    }, [logoutValue])

    return (
        <div className="container text-center">
            { isPending && <div>Loading...</div>}
            { data && 
            
            <div>
                <h2 className='text-center'>Welcome to Student { data.firstName + ' ' + data.lastName }'s CAS Journal</h2>

                <div className='row'> 
                    <div className='col'>
                        <Creativity />
                    </div>
                    <div className='col'>
                        <Activity />
                    </div>
                    <div className='col'>
                        <Service />
                    </div>
                </div> 
            </div> }
            { error && <div>{ error }</div> }
        </div>
    );
}

export default StudentPortfolio;