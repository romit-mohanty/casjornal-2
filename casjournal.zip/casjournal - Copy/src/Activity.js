import { Link } from 'react-router-dom';

const Activity = () => {
    const style = {
        backgroundColor: '#3f8acc'
    }

    return (
        <div className="card" style={style}>
            <Link to='/activity' className="text-light" style={{ textDecoration: 'none' }}>
                <div className="card-body">
                    <h5 className="card-title">Activity</h5>
                    <h6 className="card-subtitle">Click to see activity list</h6>
                </div>
            </Link>
        </div>
    );
}

export default Activity;