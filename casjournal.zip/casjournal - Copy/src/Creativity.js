import { Link } from 'react-router-dom';

const Creativity = () => {
    const style = {
        backgroundColor: '#e84653'
    }

    return (
        <div className="card" style={style}>
            <Link to='/creativity' className="text-light" style={{ textDecoration: 'none' }}>
                <div className="card-body">
                    <h5 className="card-title">Creativity</h5>
                    <h6 className="card-subtitle">Click to see creativity list</h6>
                </div>
            </Link>
        </div>
    );
}

export default Creativity;